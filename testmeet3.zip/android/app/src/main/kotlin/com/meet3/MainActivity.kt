package com.meet3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
