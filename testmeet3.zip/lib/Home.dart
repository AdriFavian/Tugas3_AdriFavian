import 'package:flutter/material.dart';

class Home extends StatelessWidget{
  @override
  Widget build(BuildContext context){
    return MaterialApp(title: 'SMK Milennial COding',
     home: Main());
  }
}

class Main extends StatelessWidget{
  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
        title: Text('Home'),
        leading: IconButton(
          onPressed: () {}
        ),
      ),
      body: Column(
        children: <Widget>[
          Text('Welcome', 
          style: const TextStyle(
            fontSize: 30,
            fontWeight: FontWeight.bold))
          Text('Google name',
          style: const TextStyle(
            fontSize: 10,
          ))];

          Row(
            children: <Widget>[
              child:Column(
                children: <Widget>[
                  Text('Product In', 
                  style: const TextStyle(
                    fontsize: 20)),
                  Text('Product Out', 
                  style: const TextStyle(
                    fontsize: 50)),
                ],

                Text('Low Stock', 
                style: const TextStyle(
                  fontSize: 30,
                  fontWeight: Fontweight.bold))
                Text('Stock Warning',
                style: const TextStyle(
                  fontsize: 10,
                  )
          
              )
              Row(
                children: <Widget> [
                  Card(
                    elevation: 2,
                    child: ClipRect(
                      borderRadius: BorderRadius.all(Radius.circular(4)),
                    // child: Image.Network('https://loremflicker.com/80/80')
                    Image.asset("assetgambar/motorre.jpg", width: 80, height: 80),

                    ),
                  ),
                  Column(
                    children: <Widget> [
                      Text('Brand new bike', 
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold)
                      ),
                      Text('BD-452', 
                      style: const TextStyle(
                        fontSize: 10 ),
                      RaisedButton(
                        child: Text('Stok 1'),
                        color: Colors.red,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.all(
                            Radius.circular(16.0))),
                            onPressed: () {},
                      )),
                    ]
                  )
                ]
              )
                Row(
                children: <Widget> [
                  Card(
                    elevation: 2,
                    child: ClipRect(
                      borderRadius: BorderRadius.all(Radius.circular(4)),
                    // child: Image.Network('https://loremflicker.com/80/80')
                    Image.asset("assetgambar/motorre.jpg", width: 80, height: 80),

                    ),
                  ),
                  Column(
                    children: <Widget> [
                      Text('Brand new bike', 
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold)
                      ),
                      Text('BD-452', 
                      style: const TextStyle(
                        fontSize: 10 ),
                      RaisedButton(
                        child: Text('Stok 1'),
                        color: Colors.red,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.all(
                            Radius.circular(16.0))),
                            onPressed: () {},
                      )),
                    ]
                  )
                ]
              )
              Icon(
                Icon.arrow_downward), size: 40),
              child:Column(
                children: <Widget>[
                  Text('Product Out', 
                  style: const TextStyle(
                    fontsize: 20)),
                  Text('4', 
                  style: const TextStyle(
                    fontsize: 50)),
                ],
              )
              Icon(
                Icon.arrow_downward), size: 40),
            ]
          )
        ]
      )
    );
  }
}

